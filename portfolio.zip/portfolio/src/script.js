// JavaScript can be used here for interactive elements, if needed.
// For example, you can add smooth scrolling or form validation here.
console.log("Welcome to My Portfolio");
